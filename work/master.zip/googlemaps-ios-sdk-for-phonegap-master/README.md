googlemaps-ios-sdk-for-phonegap
===============================
This plugin just installs Google Maps SDK for iOS to your project.

Google Maps SDK for iOS
https://developers.google.com/maps/documentation/ios/

